<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class WC_Gateway_Lemonway_User_Cards {
	
}