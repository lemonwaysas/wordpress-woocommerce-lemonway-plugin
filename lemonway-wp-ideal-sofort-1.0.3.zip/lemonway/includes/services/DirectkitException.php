<?php
class DirectkitException extends Exception{
	
}