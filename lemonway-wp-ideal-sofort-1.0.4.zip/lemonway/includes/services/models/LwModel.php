<?php

class LwModel {

	

	
}

